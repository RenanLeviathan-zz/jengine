package physics;

import objects.Sprite;
public class Collision {
	public static boolean boxCollision(Sprite s1, Sprite s2){
		boolean collided=false;
		boolean up = (s1.getHeight()+s1.getY() == s2.getY()) && (s1.getX() >= s2.getX()) && (s1.getWidth()+s1.getX() <= s2.getWidth()+s2.getX());
		boolean right = (s1.getX()+s1.getWidth() == s2.getX()) && (s1.getY()>=s2.getY()) && (s1.getY()+s1.getHeight() <= s2.getY()+s2.getHeight());
		boolean left = (s1.getX() == s2.getX()+s2.getWidth()) && (s1.getY() >= s2.getY()) && (s1.getY()+s1.getHeight() <= s2.getY()+s2.getHeight());
		if(up || right || left){
			collided=true;
		}
		return collided;
	}
	//verifica se o objeto ou o sprite atingiu as bordas da tela
	public static boolean limiteSuperior(Sprite s1){
		return (s1.getY() == 0);
	}
	public static boolean limiteInferior(Sprite s1, int frameHeight){
		return (s1.getY()+s1.getHeight() == frameHeight);
	}
	public static boolean limiteDireito(Sprite s1, int frameWidth){
		return (s1.getX()+s1.getWidth() == frameWidth);
	}
	public static boolean limiteEsquerdo(Sprite s1){
		return (s1.getX() == 0);
	}
}
