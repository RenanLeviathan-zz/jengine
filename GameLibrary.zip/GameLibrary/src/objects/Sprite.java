package objects;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Sprite{
	private int width;
	private int height;
	private int x;
	private int y;
	//coordenada dos frames da animação
	private int ix=0;
	private int iy=0;
	private ImageIcon imagem;
	public Sprite(int width, int height, int x, int y, ImageIcon image){
		this.x=x;
		this.y=y;
		this.width=width;
		this.height=height;
		this.imagem=image;
	}
	public void animar(){//para sprites com quadros de uma dimensão 1 linha x n imagens
		if(ix==this.imagem.getIconWidth()-this.getWidth()){
			ix=0;
		}else{
			ix+=this.width;
		}
	}
	public void animar(int frameY){//para sprites com quadros de dimensão n linhas x n imagens
		if(ix==this.imagem.getIconWidth()-this.getWidth()){
			ix=0;
		}else{
			ix+=this.width;
		}
		iy=frameY;
	}
	public int getX(){
		return this.x;
	}
	public int getY(){
		return this.y;
	}
	//coordenada dos frames
	public int getFrameX(){
		return this.ix;
	}
	public int getFrameY(){
		return this.iy;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Image getImage() {
		return imagem.getImage();
	}
	//movimentos
	public void direita(){
		this.x+=10;
	}
	public void esquerda(){
		this.x-=10;
	}
	public void cima(){
		this.y-=10;
	}
	public void baixo(){
		this.y+=10;
	}
}
