package core;
import javax.swing.JFrame;
public abstract class Game extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int width;
	protected int height;
	protected String title;
	private int FPS;
	public static final boolean NO_RESIZABLE = false;
	public static final boolean RESIZABLE = true;
	//construtor com parametros
	public Game(String title, int width,int height,boolean resizable){
		this.setSize(width,height);
		this.setTitle(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setResizable(resizable);
	}
	//construtor padrão
	public Game(){
		
	}
	public void setFPS(int FPS){
		this.FPS=FPS;
	}
	public int getFPS(){
		return this.FPS;
	}
	public int getWidth(){
		return this.width;
	}
	public int getHeight(){
		return this.height;
	}
	//atualiza o gráfico
	public void render(){
		
	}
	//atualiza o estado do jogo
	public void update(){
		
	}
	//carrega componentes (só precisa ser chamado uma vez)
	public void load(){
		
	}
}
